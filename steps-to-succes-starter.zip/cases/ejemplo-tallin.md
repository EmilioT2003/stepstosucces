
---
layout: case
title: "Tarifa plana de transporte para estudiantes"
pais: "Estonia"
ciudad_region: "Tallin"
sector: ["Movilidad","Educación"]
problema: "Costo de transporte limitaba acceso escolar"
intervencion: "Subsidio total para estudiantes en red de transporte"
costo_aprox: "€12M/año"
resultados: ["+8% asistencia (2019-2021)", "-5% deserción (2020)", "Satisfacción 4.3/5"]
kpis: ["Asistencia escolar","Tasa de deserción","Costo por beneficiario"]
año_inicio: 2019
replicabilidad: "Alta en ciudades con sistema integrado"
fuentes: ["https://ejemplo.org/fuente1","https://ejemplo.org/fuente2"]
curador: "Emilio"
lat: 59.437
lng: 24.7536
---

**Resumen (150–200 palabras).**
